def finish(the_final_answer: str) -> str:
    return the_final_answer

